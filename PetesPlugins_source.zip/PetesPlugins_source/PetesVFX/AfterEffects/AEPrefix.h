#include "MacHeadersCarbon++"

#define PETE_MAC_OSX
#define PETE_NATIVE_AE