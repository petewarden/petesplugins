//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by pkgSamples.rc
//
#define ID_CHOOSEFONT                   3
#define ID_LOADTEXT                     4
#define IDD_DIALOG_INPUTSIZE            130
#define IDC_EDIT_X0                     1000
#define IDC_EDIT_Y0                     1001
#define IDC_CHECK_EQUAL0                1002
#define IDD_DIALOG_SAVINGVARS           7000
#define IDC_SAVEVARS_EDIT_INT           7005
#define IDC_SAVEVARS_CHECK_BOOL         7006
#define IDC_SAVEVARS_EDIT_DWORD         7007
#define IDC_SAVEVARS_EDIT_STRING        7008
#define IDC_SAVEVARS_EDIT_FLOAT         7009
#define IDD_DIALOG1                     8000
#define IDC_CHECK_TOPBORDER             8000
#define IDD_DIALOG_XPAINT               8000
#define IDC_BUTTON_TOPBORDER            8001
#define IDD_DIALOG_INPUTS               8001
#define IDD_DIALOG_TIMEWARP             8001
#define IDC_EDIT_TOPCOLS                8002
#define IDC_CHECK_BOTBORDER             8003
#define IDC_INPUTS_CHECK_DISPLAY0       8003
#define IDC_BUTTON_BOTBORDER            8004
#define IDC_INPUTS_CHECK_DISPLAY1       8004
#define IDD_DIALOG_LEVELS               8004
#define IDC_EDIT_BOTCOLS                8005
#define IDC_INPUTS_CHECK_DISPLAY2       8005
#define IDD_DIALOG_TEXTOVERLAY          8005
#define IDC_INPUTS_CHECK_CONFIRM0       8006
#define IDD_DIALOG_METAIMAGE            8006
#define IDD_DIALOG_TIMESLICE            8007
#define IDB_LIONELBLAIR                 8008
#define IDD_DIALOG_PSHOPFILTERS         8008
#define IDC_INPUTS_CHECK_CONFIRM1       8009
#define IDC_INPUTS_CHECK_CONFIRM2       8010
#define IDC_TIMEWARP_PLAYBACKSTYLE_LIST 8010
#define IDC_TIMEWARP_FRAMESTOSTORE_EDIT 8011
#define IDC_LEVELS_STYLE_LIST           8012
#define IDC_METAIMAGE_NUMBEROFINPUTS_EDIT 8015
#define IDC_TIMESLICE_PLAYBACKSTYLE_LIST 8016
#define IDC_TIMESLICE_FRAMESTOSTORE_EDIT 8017
#define IDC_PSHOPFILTERS_FILTER_LIST    8018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        8009
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         8019
#define _APS_NEXT_SYMED_VALUE           8000
#endif
#endif
