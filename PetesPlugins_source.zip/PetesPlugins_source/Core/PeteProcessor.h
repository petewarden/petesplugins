#ifndef INCLUDE_PETEPROCESSOR_H
#define INCLUDE_PETEPROCESSOR_H

#ifdef PETE_MAC_OSX

bool Pete_IsAltiVecAvailable(void);

#endif // PETE_MAC_OSX

#endif // INCLUDE_PETEPROCESSOR_H