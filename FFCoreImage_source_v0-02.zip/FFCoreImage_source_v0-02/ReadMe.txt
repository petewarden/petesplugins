CoreImage filters in FreeFrame v0.02
------------------------------------

This is an experimental collection of Freeframe filters using the Core Image units, and requires OS X.4 (Tiger) to run.

To compile, run the createfilters shellscript, from the terminal in this directory as './createfilters'. This takes the CITwirlDistortion xcode project as a template, and creates the other CI projects using the same code, except for the filter names. I have a custom build step set up, to copy the .frf results to the desktop.

Pete Warden

freeframe@petewarden.com