
#include "CITwirlDistortion.h"
#include <string.h>
#include <stdio.h>

#import <Cocoa/Cocoa.h>
#import <QuartzCore/CIFilter.h>
#import <QuartzCore/CIContext.h>
#import <QuartzCore/CIVector.h>

#include <Accelerate/Accelerate.h>

static PlugInfoStruct g_plugInfo;
static PlugExtendedInfoStruct g_plugExtInfo;

static bool g_paramsInitialized = false;

static int g_paramsCount;
static ParamConstantsStruct g_paramConstants[maxParameters];
static int g_inputImageCount;
static ImageInfoStruct g_inputImageInfo[maxInputImages];
static char g_filterName[16];
static char g_filterID[5];

static NSString* getFilterName(void) {

	return @"CITwirlDistortion";
	
}

extern "C" void* plugMain(DWORD functionCode,void* pParam,DWORD instanceID)
{	
	plugMainUnion retval;
	plugClass* pPlugObj = (plugClass*) instanceID;

	switch(functionCode) {

	case FF_GETINFO:
		retval.PISvalue = getInfo();
		break;
	case FF_INITIALISE:
		retval.ivalue = initialise();
		break;
	case FF_DEINITIALISE:
		retval.ivalue = deInitialise();
		break;
	case FF_GETNUMPARAMETERS:
		retval.ivalue = getNumParameters();
		break;
	case FF_GETPARAMETERNAME:
		retval.svalue =  getParameterName( (DWORD) pParam );
		break;
	case FF_GETPARAMETERDEFAULT:
		retval.fvalue =  getParameterDefault( (DWORD) pParam );
		break;
	case FF_GETPARAMETERDISPLAY:
		retval.svalue =  pPlugObj->getParameterDisplay( (DWORD) pParam );
		break;	
	case FF_SETPARAMETER:
		retval.ivalue=  pPlugObj->setParameter( (SetParameterStruct*) pParam );
		break;
	case FF_PROCESSFRAME:
		retval.ivalue = pPlugObj->processFrame(pParam);
		break;
	case FF_GETPARAMETER:
		retval.fvalue =  pPlugObj->getParameter((DWORD) pParam);
		break;
	case FF_GETPLUGINCAPS:
		retval.ivalue = getPluginCaps( (DWORD) pParam);
		break;
	case FF_INSTANTIATE:
		retval.ivalue = (DWORD) instantiate( (VideoInfoStruct*) pParam);
		break;
	case FF_DEINSTANTIATE:
		retval.ivalue = deInstantiate(pPlugObj);
		break;
	case FF_GETEXTENDEDINFO: 
		retval.ivalue = (DWORD) getExtendedInfo();
		break;
	case FF_PROCESSFRAMECOPY:
		pPlugObj->processFrameCopy((ProcessFrameCopyStruct*)pParam);
		retval.ivalue = FF_SUCCESS;
		break;
	case FF_GETPARAMETERTYPE:		
		// not implemented yet
		retval.ivalue = FF_FAIL;
		break;

	default:
		retval.ivalue = FF_FAIL;
		break;
	}

	return retval.svalue;

	return FF_SUCCESS;
}

static void initializeParameters(void)
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];

	CIFilter* filter = [CIFilter filterWithName: getFilterName()];
	NSDictionary* filterAttributes = [filter attributes];
	NSArray* inputKeys = [filter inputKeys];

	const int inputKeyCount = [inputKeys count];

	int parameterCount = 0;

	int keyIndex;
	for (keyIndex = 0; keyIndex<inputKeyCount; keyIndex+=1)
	{
		NSString* currentInputKey = [inputKeys objectAtIndex: keyIndex];
		NSDictionary* currentInputAttributes = [filterAttributes objectForKey: currentInputKey];
			
		NSString* inputKeyClass = [currentInputAttributes objectForKey: kCIAttributeClass];
	
		if (([inputKeyClass isEqual:@"NSNumber"])&&(parameterCount<(maxParameters-1)))
		{
			ParamConstantsStruct* paramData = &g_paramConstants[parameterCount];
			paramData->defaultValue = 0.5;
			paramData->min = 0.0;
			paramData->max = 100.0;
			sprintf(paramData->name,"%d",parameterCount);
			paramData->type = eNumber;
			
			[currentInputKey retain];
			paramData->key = currentInputKey;
			
			NSNumber* sliderMin = [currentInputAttributes objectForKey: kCIAttributeSliderMin];
			NSNumber* sliderMax = [currentInputAttributes objectForKey: kCIAttributeSliderMax];
			NSNumber* sliderDefault = [currentInputAttributes objectForKey: kCIAttributeDefault];
			NSString* sliderName = [currentInputAttributes objectForKey: kCIAttributeDisplayName];

			if (sliderMin!=nil)
				paramData->min = [sliderMin floatValue];

			if (sliderMax!=nil)
				paramData->max = [sliderMax floatValue];

			if (sliderDefault!=nil)
			{
				const float range = (paramData->max-paramData->min);

				paramData->defaultValue = (([sliderDefault floatValue]-paramData->min)/range);
			}

			if (sliderName!=nil)
			{
				NSData* nameData = [sliderName dataUsingEncoding: NSASCIIStringEncoding
					allowLossyConversion: YES];
				
				int nameLength = [nameData length];
				if (nameLength>15)
					nameLength = 15;
				
				memset(paramData->name, 16, 0);
				memcpy(paramData->name, [nameData bytes], nameLength);
			}

			parameterCount += 1;
		}
		else if (([inputKeyClass isEqual:@"CIVector"])&&(parameterCount<(maxParameters-2)))
		{
			ParamConstantsStruct* paramData = &g_paramConstants[parameterCount];

			paramData[0].defaultValue = 0.5;
			paramData[0].min = 0.0;
			paramData[0].max = 100.0;
			sprintf(paramData[0].name,"%d X",parameterCount);
			paramData[0].type = ePositionX;

			paramData[1].defaultValue = 0.5;
			paramData[1].min = 0.0;
			paramData[1].max = 100.0;
			sprintf(paramData[1].name,"%d Y",parameterCount);
			paramData[1].type = ePositionY;
			
			[currentInputKey retain];
			paramData[0].key = currentInputKey;
			paramData[1].key = currentInputKey;
			
			CIVector* sliderMin = [currentInputAttributes objectForKey: kCIAttributeSliderMin];
			CIVector* sliderMax = [currentInputAttributes objectForKey: kCIAttributeSliderMax];
			NSString* sliderName = [currentInputAttributes objectForKey: kCIAttributeDisplayName];

			if (sliderMin!=nil)
			{
				paramData[0].min = [sliderMin X];
				paramData[1].min = [sliderMin Y];
			}

			if (sliderMax!=nil)
			{
				paramData[0].max = [sliderMax X];
				paramData[1].max = [sliderMax Y];
			}

			if (sliderName!=nil)
			{
				NSData* nameData = [sliderName dataUsingEncoding: NSASCIIStringEncoding
					allowLossyConversion: YES];
				
				int nameLength = [nameData length];
				if (nameLength>13)
					nameLength = 13;
				
				memset(paramData[0].name, 16, 0);
				memcpy(paramData[0].name, [nameData bytes], nameLength);
				strcat(paramData[0].name, " X");

				memset(paramData[1].name, 16, 0);
				memcpy(paramData[1].name, [nameData bytes], nameLength);
				strcat(paramData[1].name, " Y");
				
			}

			parameterCount += 2;
		}
		else if ([inputKeyClass isEqual:@"CIImage"])
		{			
			int imageIndex;
			if ([currentInputKey isEqual:@"inputImage"])
				imageIndex = 0;
			else
				imageIndex = g_inputImageCount;
				
			ImageInfoStruct* imageInfoData = &g_inputImageInfo[imageIndex];
			
			[currentInputKey retain];
			imageInfoData->key = currentInputKey;
			
			g_inputImageCount += 1;
		}
		else if (([inputKeyClass isEqual:@"CIColor"])&&(parameterCount<(maxParameters-4)))
		{
			ParamConstantsStruct* paramData = &g_paramConstants[parameterCount];

			paramData[0].defaultValue = 0.5;
			paramData[0].min = 0.0;
			paramData[0].max = 1.0;
			sprintf(paramData[0].name,"%d R",parameterCount);
			paramData[0].type = eColorRed;

			paramData[1].defaultValue = 0.5;
			paramData[1].min = 0.0;
			paramData[1].max = 1.0;
			sprintf(paramData[1].name,"%d G",parameterCount);
			paramData[1].type = eColorGreen;
			
			paramData[2].defaultValue = 0.5;
			paramData[2].min = 0.0;
			paramData[2].max = 1.0;
			sprintf(paramData[2].name,"%d B",parameterCount);
			paramData[2].type = eColorBlue;

			paramData[3].defaultValue = 0.5;
			paramData[3].min = 0.0;
			paramData[3].max = 1.0;
			sprintf(paramData[3].name,"%d B",parameterCount);
			paramData[3].type = eColorAlpha;
			
			[currentInputKey retain];
			paramData[0].key = currentInputKey;
			paramData[1].key = currentInputKey;
			paramData[2].key = currentInputKey;
			paramData[3].key = currentInputKey;
			
			CIColor* sliderMin = [currentInputAttributes objectForKey: kCIAttributeSliderMin];
			CIColor* sliderMax = [currentInputAttributes objectForKey: kCIAttributeSliderMax];
			CIColor* sliderDefault = [currentInputAttributes objectForKey: kCIAttributeDefault];
			NSString* sliderName = [currentInputAttributes objectForKey: kCIAttributeDisplayName];

			if (sliderMin!=nil)
			{
				paramData[0].min = [sliderMin red];
				paramData[1].min = [sliderMin green];
				paramData[2].min = [sliderMin blue];
				paramData[3].min = [sliderMin alpha];
			}

			if (sliderMax!=nil)
			{
				paramData[0].max = [sliderMax red];
				paramData[1].max = [sliderMax green];
				paramData[2].max = [sliderMax blue];
				paramData[3].max = [sliderMax alpha];
			}

			if (sliderDefault!=nil)
			{
				const float rangeR = (paramData[0].max-paramData[0].min);
				const float rangeG = (paramData[1].max-paramData[1].min);
				const float rangeB = (paramData[2].max-paramData[2].min);
				const float rangeA = (paramData[3].max-paramData[3].min);

				paramData[0].defaultValue = (([sliderDefault red]-paramData[0].min)/rangeR);
				paramData[1].defaultValue = (([sliderDefault green]-paramData[1].min)/rangeG);
				paramData[2].defaultValue = (([sliderDefault blue]-paramData[2].min)/rangeB);
				paramData[3].defaultValue = (([sliderDefault alpha]-paramData[3].min)/rangeA);
			}

			if (sliderName!=nil)
			{
				NSData* nameData = [sliderName dataUsingEncoding: NSASCIIStringEncoding
					allowLossyConversion: YES];
				
				int nameLength = [nameData length];
				if (nameLength>13)
					nameLength = 13;
				
				memset(paramData[0].name, 16, 0);
				memcpy(paramData[0].name, [nameData bytes], nameLength);
				strcat(paramData[0].name, " R");

				memset(paramData[1].name, 16, 0);
				memcpy(paramData[1].name, [nameData bytes], nameLength);
				strcat(paramData[1].name, " G");

				memset(paramData[2].name, 16, 0);
				memcpy(paramData[2].name, [nameData bytes], nameLength);
				strcat(paramData[2].name, " B");
				
				memset(paramData[3].name, 16, 0);
				memcpy(paramData[3].name, [nameData bytes], nameLength);
				strcat(paramData[3].name, " A");
				
			}

			parameterCount += 4;
		}
		else
		{
			NSLog(@"Unknown param class:%@",inputKeyClass);
		}

	}

	g_paramsCount = parameterCount;
		
	NSString* filterName = [filterAttributes objectForKey: @"CIAttributeFilterDisplayName"];
	NSData* nameData = [filterName dataUsingEncoding: NSASCIIStringEncoding
		allowLossyConversion: YES];
	
	int nameLength = [nameData length];

	unsigned int nameHash = [filterName hash];
	sprintf(g_filterID,"CI%c%c",((nameHash>>8)&0xff),((nameHash>>0)&0xff));
	
	if (nameLength>12)
		nameLength = 12;
	
	memset(g_filterName, 16, 0);
	memcpy(g_filterName, "CI ", 3);
	memcpy((g_filterName+3), [nameData bytes], nameLength);

	g_paramsInitialized = true;

	[pool release];
}

static int getFilterParameterCount(void)
{
	if (!g_paramsInitialized)
		initializeParameters();
		
	return g_paramsCount;
}

static PlugInfoStruct* getInfo() 
{
	if (!g_paramsInitialized)
		initializeParameters();

	g_plugInfo.APIMajorVersion = 1;
	g_plugInfo.APIMinorVersion = 000;	

	memcpy(g_plugInfo.uniqueID, g_filterID, 4);
	memcpy(g_plugInfo.pluginName, g_filterName, 16);

	if (g_inputImageCount>0)
		g_plugInfo.pluginType =	FF_EFFECT; 
	else
		g_plugInfo.pluginType =	FF_GENERATOR;	

	return &g_plugInfo;
}

static DWORD initialise()
{
	if (!g_paramsInitialized)
		initializeParameters();

	return FF_SUCCESS;
}

static DWORD deInitialise()
{
	return FF_SUCCESS;
}

static DWORD getNumParameters()
{
	return getFilterParameterCount();  
}

static char* getParameterName(DWORD index)
{
	return g_paramConstants[index].name;
}

static float getParameterDefault(DWORD index)
{
	return g_paramConstants[index].defaultValue;
}

char* plugClass::getParameterDisplay(DWORD index)
{
	// fill the array with spaces first
	for (int n=0; n<16; n++) {
		paramDynamicData[index].displayValue[n] = ' ';
	}

	ParamConstantsStruct* paramData = &g_paramConstants[index];
	const float range = (paramData->max-paramData->min);
	const float normalValue = paramDynamicData[index].value;
	const float expandedValue = ((normalValue*range)+paramData->min);

	sprintf(paramDynamicData[index].displayValue, "%f",expandedValue);
	return paramDynamicData[index].displayValue;

}

DWORD plugClass::setParameter(SetParameterStruct* pParam)
{
	paramDynamicData[pParam->index].value = pParam->value;
	return FF_SUCCESS;
}

float plugClass::getParameter(DWORD index)
{
	return paramDynamicData[index].value;
}

DWORD getPluginCaps(DWORD index)
{
	switch (index) {

	case 0:
		return FF_FALSE;

	case 1:
		return FF_TRUE;

	case 2:
		return FF_TRUE;

	case FF_CAP_PROCESSFRAMECOPY:
		return FF_TRUE;

	case FF_CAP_MINIMUMINPUTFRAMES:
		return 1;

	case FF_CAP_MAXIMUMINPUTFRAMES:
		return g_inputImageCount;

	case FF_CAP_COPYORINPLACE:
		return FF_CAP_PREFER_COPY;

	default:
		return FF_FALSE;
	}
}

LPVOID instantiate(VideoInfoStruct* pVideoInfo)
{
	plugClass* pPlugObj = new plugClass;

	pPlugObj->videoInfo.frameWidth = pVideoInfo->frameWidth;
	pPlugObj->videoInfo.frameHeight = pVideoInfo->frameHeight;
	pPlugObj->videoInfo.bitDepth = pVideoInfo->bitDepth;

	pPlugObj->vidmode = pPlugObj->videoInfo.bitDepth;
	if (pPlugObj->vidmode >2 || pPlugObj->vidmode < 0) {
	  return (LPVOID) FF_FAIL;
	}
	
	const int width = pVideoInfo->frameWidth;
	const int height = pVideoInfo->frameHeight;
	const int bufferByteCount = (width*height*4);

	pPlugObj->_inputCopy = new BYTE[bufferByteCount];
	pPlugObj->_outputCopy = new BYTE[bufferByteCount];

	return (LPVOID) pPlugObj;
}

DWORD deInstantiate(LPVOID instanceID)
{
	plugClass* pPlugObj = (plugClass*) instanceID;

	delete pPlugObj->_inputCopy;
	delete pPlugObj->_outputCopy;

	delete pPlugObj;
	
	return FF_SUCCESS;
}

LPVOID getExtendedInfo()
{
	g_plugExtInfo.PluginMajorVersion = 1;
	g_plugExtInfo.PluginMinorVersion = 10;

	g_plugExtInfo.Description = NULL;
	g_plugExtInfo.About = NULL;

	g_plugExtInfo.FreeFrameExtendedDataSize = 0;
	g_plugExtInfo.FreeFrameExtendedDataBlock = NULL;

	return (LPVOID) &g_plugExtInfo;
}

DWORD plugClass::processFrame(LPVOID pFrame)
{
	const int width = videoInfo.frameWidth;
	const int height = videoInfo.frameHeight;

	BYTE* inputBuffers[g_inputImageCount];
	int count;
	for (count = 0; count<g_inputImageCount; count+=1)
	{
		inputBuffers[count] = (BYTE*)(pFrame);
	}

	BYTE* outputData = (BYTE*)(pFrame);

	doRender(inputBuffers, g_inputImageCount, outputData, width, height);

	return FF_SUCCESS;
}

void plugClass::processFrameCopy(ProcessFrameCopyStruct* pArgs) {

	const int width = videoInfo.frameWidth;
	const int height = videoInfo.frameHeight;
	
	const int inputFrameCount = pArgs->numInputFrames;

	BYTE* inputBuffers[g_inputImageCount];
	int count;
	for (count = 0; count<g_inputImageCount; count+=1)
	{
		if (count<inputFrameCount)
			inputBuffers[count] = (BYTE*)(pArgs->InputFrames[count]);
		else
			inputBuffers[count] = (BYTE*)(pArgs->InputFrames[0]);
	}
	 
	BYTE* outputData = (BYTE*)(pArgs->OutputFrame);

	doRender(inputBuffers, g_inputImageCount, outputData, width, height);
}

void plugClass::doRender(BYTE** inputBuffers, int inputBufferCount, BYTE* outputData, int width, int height)
{
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];

	const int rowBytes = (width*4);
	CGSize frameSize = { width, height };

	CIFilter* filter = [CIFilter filterWithName: getFilterName()];
	
	[filter setDefaults];
	
	int currentParam;
	for (currentParam = 0; currentParam<g_paramsCount; currentParam+=1)
	{
		ParamConstantsStruct* paramData = &g_paramConstants[currentParam];
		
		const int type = paramData->type;
		
		if (type==eNumber)
		{
			const float range = (paramData->max-paramData->min);
			const float normalValue = paramDynamicData[currentParam].value;
			const float expandedValue = ((normalValue*range)+paramData->min);	
		
			[filter setValue:[NSNumber numberWithFloat: expandedValue ]
				forKey: paramData->key];
		}
		else if (type==ePositionX)
		{
			const float normalValueX = paramDynamicData[currentParam+0].value;
			const float expandedValueX = (normalValueX*width);
		
			const float normalValueY = paramDynamicData[currentParam+1].value;
			const float expandedValueY = (normalValueY*height);	
		
			[filter setValue:[CIVector vectorWithX: expandedValueX Y: expandedValueY]
				forKey: paramData->key];
		
		}
		else if (type==eColorRed)
		{
			const float rangeR = (paramData[0].max-paramData[0].min);
			const float normalValueR = paramDynamicData[currentParam+0].value;
			const float valueR = ((normalValueR*rangeR)+paramData[0].min);	
		
			const float rangeG = (paramData[1].max-paramData[1].min);
			const float normalValueG = paramDynamicData[currentParam+1].value;
			const float valueG = ((normalValueG*rangeG)+paramData[1].min);	
		
			const float rangeB = (paramData[2].max-paramData[2].min);
			const float normalValueB = paramDynamicData[currentParam+2].value;
			const float valueB = ((normalValueB*rangeB)+paramData[2].min);	

			const float rangeA = (paramData[3].max-paramData[3].min);
			const float normalValueA = paramDynamicData[currentParam+3].value;
			const float valueA = ((normalValueA*rangeA)+paramData[3].min);	
		
			[filter setValue:[CIColor colorWithRed: valueR green: valueG blue: valueB alpha: valueA]
				forKey: paramData->key];
		
		}

	}
	
	int inputImageIndex;
	for (inputImageIndex = 0; inputImageIndex<inputBufferCount; inputImageIndex+=1)
	{
		NSData* imageNSData = [NSData dataWithBytesNoCopy: inputBuffers[inputImageIndex]
			length: (width*height*4)
			freeWhenDone: NO];

		CIImage* image = [CIImage imageWithBitmapData: imageNSData 
			bytesPerRow: (videoInfo.frameWidth*4)
			size: frameSize
			format: kCIFormatARGB8
			colorSpace: nil];

		[filter setValue: image
			forKey: g_inputImageInfo[inputImageIndex].key];

	}

	CIImage* result = [filter valueForKey:@"outputImage"];

	unsigned char* outputDataArray[1] = { _outputCopy };

	NSBitmapImageRep* outputBitmap = [[NSBitmapImageRep alloc]  
		initWithBitmapDataPlanes: outputDataArray
		pixelsWide: videoInfo.frameWidth  
		pixelsHigh: videoInfo.frameHeight
		bitsPerSample: 8
		samplesPerPixel: 4  
		hasAlpha: YES
		isPlanar: NO
		colorSpaceName: NSDeviceRGBColorSpace  
		bytesPerRow: 0
		bitsPerPixel: 0];

	vImage_Buffer outputCopyVImage = { _outputCopy, height, width, rowBytes };
	Pixel_8888 fillColor = { 0, 0, 0, 0 };
	vImageBufferFill_ARGB8888( &outputCopyVImage, fillColor, 0 );

	NSGraphicsContext *nsContext = [NSGraphicsContext  
		graphicsContextWithBitmapImageRep: outputBitmap];

	[NSGraphicsContext saveGraphicsState];
	[NSGraphicsContext setCurrentContext: nsContext];

	CGRect drawRect;
	drawRect.origin.x = 0;
	drawRect.origin.y = 0;
	drawRect.size.width = width;
	drawRect.size.height = height;

	[[nsContext CIContext] drawImage: result
		inRect: drawRect
		fromRect: drawRect ];

	[NSGraphicsContext restoreGraphicsState];
	
//	printf("OC:%x, %x, %x, %x (0x%x)\n", _outputCopy[0], _outputCopy[1], _outputCopy[2], _outputCopy[3], *(DWORD*)(_outputCopy));

	vImage_Buffer originalOutputVImage = { outputData, height, width, rowBytes };
	BYTE outputPermuteMap[4] = { 3, 0, 1, 2 };

	vImage_Error permuteOutputError = vImagePermuteChannels_ARGB8888 ( &outputCopyVImage, &originalOutputVImage, outputPermuteMap, 0);
	assert(permuteOutputError==kvImageNoError);

//	printf("On:%x, %x, %x, %x (0x%x)\n", outputData[0], outputData[1], outputData[2], outputData[3], *(DWORD*)(outputData));

	[outputBitmap release];

	[pool release];

}