///////////////////////////////////////////////////////////////////////////////////

#ifndef __FREEFRAMESAMPLE_H__
#define __FREEFRAMESAMPLE_H__

#include "FreeFrame.h"

#import <cocoa/cocoa.h>

enum { eNumber, ePositionX, ePositionY, eImage, eColorRed, eColorGreen, eColorBlue, eColorAlpha };

typedef struct ParamConstsStructTag {
	float defaultValue;
	char name[16];
	float min;
	float max;
	NSString* key;
	int type;
} ParamConstantsStruct;

typedef struct ImageInfoStructTag {
	NSString* key;
} ImageInfoStruct;

typedef struct ParamDynamicDataStructTag {
	float value;
	char displayValue[16];
} ParamDynamicDataStruct;

const int maxParameters = 32;
const int maxInputImages = 32;

class plugClass {

public:

	char* getParameterDisplay(DWORD index);			
	DWORD setParameter(SetParameterStruct* pParam);		
	float getParameter(DWORD index);					
	DWORD processFrame(LPVOID pFrame);
	void processFrameCopy(ProcessFrameCopyStruct* pArgs);
	void doRender(BYTE** inputBuffers, int inputBuffersCount, BYTE* outputData, int width, int height);

	ParamDynamicDataStruct paramDynamicData[maxParameters];
	VideoInfoStruct videoInfo;
	int vidmode;

	BYTE* _inputCopy;
	BYTE* _outputCopy;

};

static PlugInfoStruct*	getInfo();							
static DWORD	initialise();								
static DWORD	deInitialise();								
static DWORD	getNumParameters();							
static char*	getParameterName(DWORD index);				
static float	getParameterDefault(DWORD index);			
static DWORD	getPluginCaps(DWORD index);	
static LPVOID instantiate(VideoInfoStruct* pVideoInfo);
static DWORD deInstantiate(LPVOID instanceID);	
static LPVOID getExtendedInfo();		

#endif
