//
//	LiveFeed.m
//	LiveFeed
//
//	Created by Pete Warden on 4/7/05.
//	Copyright __MyCompanyName__ 2005. All rights reserved.
//

#include <PluginManager/PROPluginManager.h>
#include <FxPlugImage/FxPlug_Image.h>
#include <FxPlugImage/FxPlug_Bitmap.h>
#include <FxPlugImage/FxPlug_Texture.h>

#include "FxPlug_ParameterAPI.h"
#include "FxPlug_AltParametersAPI.h"
#include "FxPlug_Effect.h"
#include "FxPlug_Generator.h"

#include <ProCore/PCMath.h>

#include <QuickTime/QuickTime.h>

#include <OpenGL/gl.h>
#include <OpenGL/glext.h>
#include <OpenGL/glu.h>

#include "EffectHelpers.h"
#include "UtilRandom.h"
#include "GaussianBlur.h"

enum
{
	SPEED_ID = 1,
};

typedef struct {
    Rect 				boundsRect;	// bounds rect
    GWorldPtr 		 	pGWorld;	// offscreen
    SeqGrabComponent 	seqGrab;	// sequence grabber
    ImageSequence 	 	decomSeq;	// unique identifier for our decompression sequence
    ImageSequence 	 	drawSeq;	// unique identifier for our draw sequence
	int					rowBytes;
    long 			 	drawSize;
    TimeValue 		 	lastTime;
    TimeScale 		 	timeScale;
    long 			 	frameCount;
	GLuint				textureID;
} MungDataRecord, *MungDataPtr;

#define BailErr(x) {err = x; if(err != noErr) fprintf(stderr,"Error '%d' :%s, %d\n",err,__FILE__,__LINE__);}

OSErr InitializeMungData(Rect inBounds);
SeqGrabComponent MakeSequenceGrabber(WindowRef pWindow);
OSErr MakeSequenceGrabChannel(SeqGrabComponent seqGrab, SGChannel *sgchanVideo, Rect const *rect);
pascal OSErr MungGrabDataProc(SGChannel c, Ptr p, long len, long *offset, long chRefCon, TimeValue time, short writeType, long refCon);

@interface LiveFeed : NSObject < FxPlug_Generator >
{
    id			_apiManager;
    
	MungDataRecord* _mungData;
	
	int			_resourceWidth;
	int			_resourceHeight;
}

@end

// --------------------
// InitializeMungData
//
OSErr InitializeMungData(Rect inBounds,MungDataRecord** mungDataPtr)
{
    CGrafPtr theOldPort;
    GDHandle theOldDevice;
    
    OSErr err = noErr;
    
    // allocate memory for the data
    *mungDataPtr = (MungDataPtr)NewPtrClear(sizeof(MungDataRecord));
    MungDataRecord* _mungData = *mungDataPtr;
	
	if (MemError() || NULL == _mungData ) return NULL;
    
    // create a GWorld
    err = QTNewGWorld(&(_mungData->pGWorld),	// returned GWorld
    					k32ARGBPixelFormat,		// pixel format
    					&inBounds,				// bounds
    					0,						// color table
    					NULL,					// GDHandle
    					0);						// flags
	BailErr(err);
    
    // lock the pixmap and make sure it's locked because
    // we can't decompress into an unlocked pixmap
    if(!LockPixels(GetGWorldPixMap(_mungData->pGWorld)))
	{
		BailErr(-23);
		goto bail;
	}
    
    GetGWorld(&theOldPort, &theOldDevice);    
    SetGWorld(_mungData->pGWorld, NULL);
    BackColor(blackColor);
    ForeColor(whiteColor);
    EraseRect(&inBounds);    
    SetGWorld(theOldPort, theOldDevice);

	_mungData->boundsRect = inBounds;

    {
		ImageDescriptionHandle desc = NULL;
		PixMapHandle hPixMap = GetGWorldPixMap(_mungData->pGWorld);
		Rect bounds;
		
		GetPixBounds(hPixMap, &bounds);

		err = MakeImageDescriptionForPixMap(hPixMap, &desc);
		BailErr(err);
		
		_mungData->rowBytes = GetPixRowBytes(hPixMap);
		
		_mungData->drawSize = (GetPixRowBytes(hPixMap) * (*desc)->height);

		if (desc)
			DisposeHandle((Handle)desc);
	}

bail:
	return err;
}

pascal OSErr MungGrabDataProc(SGChannel c, Ptr p, long len, long *offset, long chRefCon, TimeValue time, short writeType, long refCon)
{
	MungDataRecord* _mungData = (MungDataRecord*)(refCon);

    CGrafPtr	theSavedPort;
    GDHandle    theSavedDevice;
    CodecFlags	ignore;
    float		fps = 0,
       			averagefps = 0;
    char		status[64];
	Str255		theString; 
    
    ComponentResult err = noErr;

    GetGWorld(&theSavedPort, &theSavedDevice);    
    SetGWorld(_mungData->pGWorld, NULL);
	
	// reset frame and time counters after a stop/start
	if (_mungData->lastTime > time) {
		_mungData->lastTime = 0;
		_mungData->frameCount = 0;
	}
    
    _mungData->frameCount++;
        
    if (_mungData->timeScale == 0) {
    	// first time here so set the time scale
    	err = SGGetChannelTimeScale(c, &_mungData->timeScale);
    	BailErr(err);
    }
    
	if (_mungData->pGWorld) {
    	if (_mungData->decomSeq == 0) {
    		// Set up getting grabbed data into the GWorld
    		
    		Rect				   sourceRect = { 0, 0 };
			MatrixRecord		   scaleMatrix;
			ImageDescriptionHandle imageDesc = (ImageDescriptionHandle)NewHandle(0);
            
            // retrieve a channel’s current sample description, the channel returns a sample description that is
            // appropriate to the type of data being captured
            err = SGGetChannelSampleDescription(c, (Handle)imageDesc);
            BailErr(err);
                        
            // make a scaling matrix for the sequence
			sourceRect.right = (**imageDesc).width;
			sourceRect.bottom = (**imageDesc).height;
			RectMatrix(&scaleMatrix, &sourceRect, &_mungData->boundsRect);
			
            // begin the process of decompressing a sequence of frames
            // this is a set-up call and is only called once for the sequence - the ICM will interrogate different codecs
            // and construct a suitable decompression chain, as this is a time consuming process we don't want to do this
            // once per frame (eg. by using DecompressImage)
            // for more information see Ice Floe #8 http://developer.apple.com/quicktime/icefloe/dispatch008.html
            // the destination is specified as the GWorld
			err = DecompressSequenceBegin(&_mungData->decomSeq,	// pointer to field to receive unique ID for sequence
										  imageDesc,			// handle to image description structure
										  _mungData->pGWorld,   // port for the DESTINATION image
										  NULL,					// graphics device handle, if port is set, set to NULL
										  NULL,					// source rectangle defining the portion of the image to decompress 
                                          &scaleMatrix,			// transformation matrix
                                          srcCopy,				// transfer mode specifier
                                          (RgnHandle)NULL,		// clipping region in dest. coordinate system to use as a mask
                                          NULL,					// flags
                                          codecNormalQuality, 	// accuracy in decompression
                                          bestSpeedCodec);		// compressor identifier or special identifiers ie. bestSpeedCodec
            BailErr(err);
            
            DisposeHandle((Handle)imageDesc);         
            
        }
        
        // decompress a frame into the GWorld - can queue a frame for async decompression when passed in a completion proc
        err = DecompressSequenceFrameS(_mungData->decomSeq,	// sequence ID returned by DecompressSequenceBegin
        							   p,					// pointer to compressed image data
        							   len,					// size of the buffer
        							   0,					// in flags
        							   &ignore,				// out flags
        							   NULL);				// async completion proc

		if (err) {
            fprintf(stderr,"DecompressSequenceFrameS gave error %ld (%lx)",err,err);
            err = noErr;
		} else {	
//		   GetPixBaseAddr(GetGWorldPixMap(gMungData->pGWorld)),	// pointer image data
//		   gMungData->drawSize,									// size of the buffer
			
			char* videoData = GetPixBaseAddr(GetGWorldPixMap(_mungData->pGWorld));
//			const int videoDataSize = _mungData->drawSize;
//			fprintf(stderr,"0x%x:%dk\n",videoData,videoDataSize);

			glBindTexture(GL_TEXTURE_RECTANGLE_EXT, _mungData->textureID);
			glTexSubImage2D(GL_TEXTURE_RECTANGLE_EXT, 0, 0, 0, 
				(_mungData->rowBytes/4), _mungData->boundsRect.bottom, 
				GL_BGRA_EXT, GL_UNSIGNED_INT_8_8_8_8_REV, videoData);

		}
	}
            
    _mungData->lastTime = time;

    SetGWorld(theSavedPort, theSavedDevice);
	
	return err;
}

// --------------------
// MakeSequenceGrabber
//
void MakeSequenceGrabber(MungDataRecord* _mungData)
{
	OSErr			 err = noErr;

    // open the default sequence grabber
    _mungData->seqGrab = OpenDefaultComponent(SeqGrabComponentType, 0);
    if (_mungData->seqGrab != NULL) { 
    	// initialize the default sequence grabber component
    	err = SGInitialize(_mungData->seqGrab);

    	if (err == noErr)
        	// set its graphics world to the specified window
        	err = SGSetGWorld(_mungData->seqGrab, _mungData->pGWorld, NULL );
    	
    	if (err == noErr)
    		// specify the destination data reference for a record operation
    		// tell it we're not making a movie
    		// if the flag seqGrabDontMakeMovie is used, the sequence grabber still calls
    		// your data function, but does not write any data to the movie file
    		// writeType will always be set to seqGrabWriteAppend
    		err = SGSetDataRef(_mungData->seqGrab,
    						   0,
    						   0,
    						   seqGrabDontMakeMovie);
    }

    if (err && (_mungData->seqGrab != NULL)) { // clean up on failure
    	CloseComponent(_mungData->seqGrab);
        _mungData->seqGrab = NULL;
    }
}

// --------------------
// MakeSequenceGrabChannel
//
OSErr MakeSequenceGrabChannel(SeqGrabComponent seqGrab, SGChannel *sgchanVideo, Rect const *rect)
{
    long  flags = 0;
    
    OSErr err = noErr;
    
    err = SGNewChannel(seqGrab, VideoMediaType, sgchanVideo);
	BailErr(err);
    if (err == noErr) {
	    err = SGSetChannelBounds(*sgchanVideo, rect);
		BailErr(err);
	    if (err == noErr)
	    	// set usage for new video channel to avoid playthrough
	   		// note we don't set seqGrabPlayDuringRecord
	    	err = SGSetChannelUsage(*sgchanVideo, flags | seqGrabRecord );
	    
	    if (err != noErr) {
	        // clean up on failure
	        SGDisposeChannel(seqGrab, *sgchanVideo);
	        *sgchanVideo = NULL;
	    }
    }

	return err;
}

@implementation LiveFeed : NSObject

- (id)initWithManager: (id)apiManager
{
    _apiManager = apiManager;

	_mungData = NULL;

    return self;
}

- (void) dealloc
{
    [super dealloc];
}

- (BOOL)variesOverTime
{
	return YES;
}

- (BOOL) addParameters
{
    id parmsApi;

    parmsApi = [_apiManager apiForProtocol:@protocol(FxPlug_ParameterCreationAPI)];

    if ( NULL != parmsApi )
    {
		NSBundle *bundle = [NSBundle bundleForClass: [self class]];
    }
    
    return true;
}

- (BOOL)parameterChanged: (UInt32)parmId
{
    return YES;
}

- (BOOL)getOutputWidth: (UInt32 *)width
                height: (UInt32 *)height
             withInput: (FxPlug_ImageInfo)inputInfo
              withInfo: (FxPlug_RenderInfo)renderInfo
{
    bool retval = true;
    
    if ( NULL != width && NULL != height )
    {
        *width	= inputInfo.width;
        *height = inputInfo.height;
    }
    else
        retval = false;

    return retval;
}

- (BOOL)renderOutput: (FxPlug_Image *)outputImage
            withInfo: (FxPlug_RenderInfo)renderInfo
{
    const int width = [outputImage width];
    const int height = [outputImage height];

	OSErr err;

	if (_mungData==NULL)
	{
		Rect portRect = { 0, 0, height, width };
		
		// initialize our data
		err = InitializeMungData(portRect, &_mungData);
		BailErr(err);
		
		// create and initialize the sequence grabber
		MakeSequenceGrabber(_mungData);
		BailErr(NULL == _mungData->seqGrab);
		
		// create the channel
		SGChannel sgchanVideo;
		err = MakeSequenceGrabChannel(_mungData->seqGrab, &sgchanVideo, &portRect);
		BailErr(err);
		
		// specify a data function
		err = SGSetDataProc(_mungData->seqGrab, NewSGDataUPP(MungGrabDataProc), _mungData);
		BailErr(err);
		
		// lights...camera...
		err = SGPrepare(_mungData->seqGrab, false, true);
		BailErr(err); 
		
		// ...action
		err = SGStartRecord(_mungData->seqGrab);
		BailErr(err);

		glGenTextures(1, &_mungData->textureID);
		glBindTexture(GL_TEXTURE_RECTANGLE_EXT, _mungData->textureID);
		glTexImage2D(GL_TEXTURE_RECTANGLE_EXT, 0, GL_RGBA8, (_mungData->rowBytes/4), height,
			0, GL_BGRA_EXT, GL_UNSIGNED_INT_8_8_8_8_REV, NULL);
	}

    id parmsApi = [_apiManager apiForProtocol:@protocol(FxPlug_ParameterRetrievalAPI)];
	if (parmsApi==NULL)
        return false;
		
	err = SGIdle(_mungData->seqGrab);

	if (err) {
		if (err == cDepthErr) {		
			fprintf(stderr, "cDepthErr \n");
		} else {
			fprintf(stderr,"Stopped, esc to continue %d\n",err);
		}
		SGStop(_mungData->seqGrab);
		SGStartRecord(_mungData->seqGrab);
		return false;
	}
	
	glEnable(GL_TEXTURE_RECTANGLE_EXT);
	glBindTexture(GL_TEXTURE_RECTANGLE_EXT, _mungData->textureID);
	
	const float textureLeft = 0;
	const float textureRight = width;
	const float textureBottom = height;
	const float textureTop = 0;

    FxPlug_Texture *outTex = (FxPlug_Texture *)outputImage;
    double outLeft, outRight, outTop, outBottom;
    [outTex getTextureCoords: &outLeft
                       Right: &outRight
                      Bottom: &outBottom
                         Top: &outTop];
	
	glBegin(GL_QUADS);

	glTexCoord2f(textureLeft,textureBottom);
	glVertex2f(outLeft,outBottom);
	
	glTexCoord2f(textureRight,textureBottom);
	glVertex2f(outRight,outBottom);

	glTexCoord2f(textureRight,textureTop);
	glVertex2f(outRight,outTop);

	glTexCoord2f(textureLeft,textureTop);
	glVertex2f(outLeft,outTop);

	glEnd();

    return true;
}

- (BOOL)frameSetup: (FxPlug_RenderInfo)renderInfo
          hardware: (bool *)canRenderHardware
          software: (bool *)canRenderSoftware
{
    bool retval = true;

    *canRenderSoftware = false;
    *canRenderHardware = true;

    return retval;
    
}

- (bool)frameCleanup
{
    return true;
}

@end

/*

#import "LiveFeed.h"

#import <FxPlug/FxPlugSDK.h>

#include <OpenGL/gl.h>
#include <OpenGL/glext.h>
#include <OpenGL/glu.h>

#define kBrightnessParamID	1

//
// ARB Fragment Program
//

static const char *brightnessARBFragmentProgram =
"!!ARBfp1.0\n"
"TEMP inSample;\n"
"TEX inSample, fragment.texcoord[0], texture[0], RECT;\n"
"MUL result.color, inSample, program.local[0];\nEND";

//
// Software Image Operation Function
//

static void brightness( float	*inputBuffer,
						float	*outputBuffer,
						UInt32	 numToDo,
						float	 brightAmt )
{
	UInt32 x;
	for ( x = 0; x < numToDo; ++x )
	{
		double temp = *inputBuffer++ * brightAmt;

		*outputBuffer++ = temp > 1.0 ? 1.0 : temp;
	}
}

@implementation LiveFeed

- (id)initWithAPIManager:(id)apiManager;
{
	const GLubyte *extensions = glGetString( GL_EXTENSIONS );

	BOOL cardSupportsARB = strstr( (const char *)extensions, "GL_ARB_fragment_program" ) != NULL;

	_apiManager     = apiManager;
	_cachedBright 	= -1;
	_cachedLUT		= NULL;
	_lutDepth		= 0;

	if ( cardSupportsARB )
	{
		GLint isUnderNativeLimits;

		glGenProgramsARB( 1, &_programID );
		glBindProgramARB( GL_FRAGMENT_PROGRAM_ARB, _programID );
		glProgramStringARB( GL_FRAGMENT_PROGRAM_ARB,
							GL_PROGRAM_FORMAT_ASCII_ARB,
							strlen( brightnessARBFragmentProgram ),
							brightnessARBFragmentProgram );

		glBindProgramARB( GL_FRAGMENT_PROGRAM_ARB, _programID );

		glGetProgramivARB( GL_FRAGMENT_PROGRAM_ARB,
						   GL_PROGRAM_UNDER_NATIVE_LIMITS_ARB,
						   &isUnderNativeLimits );

		_canDoHardware = ( isUnderNativeLimits == 1 );
	}

	return self;
}

- (void)dealloc
{
	glDeleteProgramsARB( 1, &_programID );

	if ( _cachedLUT != NULL )
		free( _cachedLUT );

	[super dealloc];
}

- (BOOL)variesOverTime
{
	return NO;
}

- (BOOL)addParameters
{
	id parmsApi;

	parmsApi = [_apiManager apiForProtocol:@protocol(FxParameterCreationAPI)];

	if ( parmsApi != NULL )
	{
		NSBundle *bundle = [NSBundle bundleForClass:[self class]];

		[parmsApi addFloatSliderWithName:[bundle localizedStringForKey: @"LiveFeed::LiveFeed"
																 value: NULL
																 table: NULL]
								  parmId:kBrightnessParamID
							defaultValue:1.0
							parameterMin:0.0
							parameterMax:100.0
							   sliderMin:0.0
							   sliderMax:5.0
								   delta:0.1
							   parmFlags:kFxParameterFlag_DEFAULT];
	}
	else
		printf( "Couldn't find protocol to add slider!\n" );

	return YES;
}

- (BOOL)parameterChanged:(UInt32)parmId
{
	return YES;
}

- (BOOL)getOutputWidth:(UInt32 *)width
				height:(UInt32 *)height
			 withInput:(FxImageInfo)inputInfo
			  withInfo:(FxRenderInfo)renderInfo
{
	BOOL retval = YES;

	if ( width != NULL && height != NULL )
	{
		*width	= inputInfo.width;
		*height = inputInfo.height;
	}
	else
		retval = NO;

	return retval;
}

- (BOOL)renderOutput:(FxImage *)outputImage
		   withInput:(FxImage *)inputImage
			withInfo:(FxRenderInfo)renderInfo
{
	BOOL retval = YES;

	id parmsApi;

	parmsApi = [_apiManager apiForProtocol:@protocol(FxParameterRetrievalAPI)];

	if ( parmsApi != NULL )
	{
		double	bright;

		[parmsApi getFloatValue:&bright
					   fromParm:kBrightnessParamID
						 atTime:renderInfo.frame];

		if ( [inputImage imageType] == kFxImageType_TEXTURE )
		{
			double left, right, top, bottom;
			double tLeft, tRight, tTop, tBottom;
			FxTexture *inTex = (FxTexture *)inputImage;
			FxTexture *outTex = (FxTexture *)outputImage;

			glTexEnvi( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			[inTex getTextureCoords:&tLeft
							  right:&tRight
							 bottom:&tBottom
								top:&tTop];

			[outTex getTextureCoords:&left
							   right:&right
							  bottom:&bottom
								 top:&top];

			glEnable( GL_FRAGMENT_PROGRAM_ARB );
			glBindProgramARB( GL_FRAGMENT_PROGRAM_ARB, _programID );

			// Don't affect alpha!
			glProgramLocalParameter4fARB( GL_FRAGMENT_PROGRAM_ARB, 0, bright, bright, bright, 1.0 );

			[inTex bind];
			[inTex enable];

			glBegin(GL_QUADS);
			{
				glTexCoord2f( tLeft, tBottom );
				glVertex2f( left, bottom );
				glTexCoord2f( tRight, tBottom );
				glVertex2f( right, bottom );
				glTexCoord2f( tRight, tTop );
				glVertex2f( right, top );
				glTexCoord2f( tLeft, tTop );
				glVertex2f( left, top );
			}
			glEnd();

			glDisable( GL_FRAGMENT_PROGRAM_ARB );

			[inTex disable];            
		}
		else if ( [inputImage imageType] == kFxImageType_BITMAP )
		{
			FxBitmap	*inMap		= (FxBitmap *)inputImage;
			FxBitmap	*outMap 	= (FxBitmap *)outputImage;

			switch( [outputImage depth] )
			{
				case 8:
				{
					if ( _lutDepth != 8 || bright != _cachedBright )
					{
						if ( _cachedLUT != NULL )
							free( _cachedLUT );

						_cachedLUT = (float *)malloc( 256 * sizeof( float ));
						
						UInt32 i;
						for ( i = 0; i < 256; ++i )
							_cachedLUT[i] = (float)i / 255.0;

						brightness( _cachedLUT, _cachedLUT, 256, bright );

						_cachedBright	= bright;
						_lutDepth	= 8;
					}

					UInt8 *inData	= (UInt8 *)[inMap dataPtr];
					UInt8 *outData	= (UInt8 *)[outMap dataPtr];
					
					UInt32	y;
					for ( y = 0; y < [outMap height]; ++y )
					{
						UInt32 x;
						for ( x = 0; x < [outMap width]; ++x )
						{
							*outData++ = (UInt8)( _cachedLUT[(*inData++)] * 255 );
							*outData++ = (UInt8)( _cachedLUT[(*inData++)] * 255 );
							*outData++ = (UInt8)( _cachedLUT[(*inData++)] * 255 );
							*outData++ = (UInt8)( _cachedLUT[(*inData++)] * 255 );
						}
					}

					break;
				}
				case 16:
				{
					if ( _lutDepth != 166 || bright != _cachedBright )
					{
						if ( _cachedLUT != NULL )
							free( _cachedLUT );

						_cachedLUT = (float *)malloc( 65536 * sizeof( float ));
						
						UInt32 i;
						for ( i = 0; i < 65536; ++i )
							_cachedLUT[i] = (float)i / 65535.0;

						brightness( _cachedLUT, _cachedLUT, 65535, bright );

						_cachedBright	= bright;
						_lutDepth	= 16;
					}

					UInt16 *inData	= (UInt16 *)[inMap dataPtr];
					UInt16 *outData	= (UInt16 *)[inMap dataPtr];
					
					UInt32 y;
					for ( y = 0; y < [outMap height]; ++y )
					{
						UInt32 x;
						for ( x = 0; x < [outMap width]; ++x )
						{
							*outData++ = (UInt16)( _cachedLUT[*inData++] * 65535 );
							*outData++ = (UInt16)( _cachedLUT[*inData++] * 65535 );
							*outData++ = (UInt16)( _cachedLUT[*inData++] * 65535 );
							*outData++ = (UInt16)( _cachedLUT[*inData++] * 65535 );
						}
					}

					break;
				}
				case 32:
				{
					float	*inData		= (float *)[inMap dataPtr];
					float	*outData	= (float *)[outMap dataPtr];

					brightness( inData, outData, [outMap width] * [outMap height], bright );

					_lutDepth = 32;

					break;
				}
			}
		}
		else
			retval = NO;
	}
	else
		retval = NO;

	return retval;
}

- (BOOL)frameSetup:(FxRenderInfo)renderInfo
		 inputInfo:(FxImageInfo)inputInfo
		  hardware:(BOOL *)canRenderHardware
		  software:(BOOL *)canRenderSoftware
{
	*canRenderSoftware = YES;
	*canRenderHardware = _canDoHardware;

	return YES;
}

- (BOOL)frameCleanup
{
	return YES;
}

@end
*/