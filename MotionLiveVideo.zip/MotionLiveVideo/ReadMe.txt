Live Feed Generator For Motion

This is an example of an FxPlug generator that will display a live video feed in Apple Motion.

Installing
----------

Create new folder, "Plug-Ins" (note the - in there, it won't load without it) inside your Library folder (either the one at the top of your boot drive, or the one in your home folder).

Inside that folder, create another folder called "FxPlug" and drag the LiveFeed.fxplug folder into it.

I've included a screenshot showing an example of this set up in this file as WhereToPutPlugin.png.

Running
-------

If the plugin installed correctly, you should now see a "LiveFeed" entry inside the Generators tab in Motion's library. Drag the new generator into a project to use it just like any other.

I've included a LiveFeedExample.motn project to demonstrate.

There are some things to watch out for:

Because of the way quicktime works, only one device can grab the video at once. This means you can only have one generator running at once, and no other programs can be also grabbing the video.

The generator doesn't shut down correctly, so you'll need to restart Motion if it gets deleted and you want to use another one.

It grabs the first video input device it finds, so this won't work correctly if you have multiple video inputs in your machine.

Compiling
---------

Load and build the project in XCode. The code is based on the SonOfMung Quicktime example code, and the FxPlug example code, and is available under the GPL (see the licence file for details).

Pete Warden
livefeed@petewarden.com