CoreImage filters in FreeFrame v0.02
------------------------------------

This is an experimental collection of Freeframe filters using the Core Image units, and requires OS X.4 (Tiger) to run. The source code is available for all of these from petewarden.com

Copy these plugins over to the freeframe plugin folder of the app you're running to use them. 

Pete Warden
freeframe@petewarden.com